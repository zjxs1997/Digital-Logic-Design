/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Project/xilinx/clock/bin_bcd.v";
static int ng1[] = {0, 0};
static int ng2[] = {15, 0};
static unsigned int ng3[] = {4U, 0U};
static unsigned int ng4[] = {3U, 0U};
static int ng5[] = {3, 0};
static int ng6[] = {7, 0};
static int ng7[] = {4, 0};
static int ng8[] = {11, 0};
static int ng9[] = {8, 0};
static int ng10[] = {12, 0};
static int ng11[] = {1, 0};



static void Always_30_0(char *t0)
{
    char t13[8];
    char t23[8];
    char t32[8];
    char t40[8];
    char t42[8];
    char t43[8];
    char t44[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    int t30;
    unsigned int t31;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t41;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    unsigned int t51;
    char *t52;
    unsigned int t53;
    int t54;
    char *t55;
    unsigned int t56;
    int t57;
    int t58;
    unsigned int t59;
    int t60;
    unsigned int t61;
    unsigned int t62;
    int t63;
    int t64;

LAB0:    t1 = (t0 + 3168U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 3488);
    *((int *)t2) = 1;
    t3 = (t0 + 3200);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(31, ng0);

LAB5:    xsi_set_current_line(32, ng0);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    t4 = (t0 + 2088);
    xsi_vlogvar_assign_value(t4, t5, 0, 0, 16);
    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2248);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 16);
    xsi_set_current_line(36, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t2);
    t9 = (t8 & t7);
    t4 = (t0 + 4968);
    *((int *)t4) = t9;

LAB6:    t5 = (t0 + 4968);
    if (*((int *)t5) > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 15);
    t8 = (t7 & 1);
    *((unsigned int *)t13) = t8;
    t16 = *((unsigned int *)t10);
    t17 = (t16 >> 15);
    t18 = (t17 & 1);
    *((unsigned int *)t5) = t18;
    t11 = (t0 + 2248);
    t12 = (t0 + 2248);
    t14 = (t12 + 72U);
    t15 = *((char **)t14);
    t22 = ((char*)((ng1)));
    xsi_vlog_generic_convert_bit_index(t23, t15, 2, t22, 32, 1);
    t24 = (t23 + 4);
    t19 = *((unsigned int *)t24);
    t9 = (!(t19));
    if (t9 == 1)
        goto LAB52;

LAB53:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 12);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 12);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = (t0 + 1448);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 4);
    xsi_set_current_line(50, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 8);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 8);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = (t0 + 1608);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 4);
    xsi_set_current_line(51, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 4);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 4);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = (t0 + 1768);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 4);
    xsi_set_current_line(52, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 0);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = (t0 + 1928);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 4);
    goto LAB2;

LAB7:    xsi_set_current_line(38, ng0);

LAB9:    xsi_set_current_line(39, ng0);
    t10 = (t0 + 2088);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t13, 0, 8);
    t14 = (t13 + 4);
    t15 = (t12 + 4);
    t16 = *((unsigned int *)t12);
    t17 = (t16 >> 15);
    t18 = (t17 & 1);
    *((unsigned int *)t13) = t18;
    t19 = *((unsigned int *)t15);
    t20 = (t19 >> 15);
    t21 = (t20 & 1);
    *((unsigned int *)t14) = t21;
    t22 = (t0 + 2248);
    t24 = (t0 + 2248);
    t25 = (t24 + 72U);
    t26 = *((char **)t25);
    t27 = ((char*)((ng1)));
    xsi_vlog_generic_convert_bit_index(t23, t26, 2, t27, 32, 1);
    t28 = (t23 + 4);
    t29 = *((unsigned int *)t28);
    t30 = (!(t29));
    if (t30 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 0);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = ((char*)((ng3)));
    memset(t23, 0, 8);
    t12 = (t13 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB13;

LAB12:    t14 = (t11 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB13;

LAB16:    if (*((unsigned int *)t13) > *((unsigned int *)t11))
        goto LAB14;

LAB15:    t22 = (t23 + 4);
    t19 = *((unsigned int *)t22);
    t20 = (~(t19));
    t21 = *((unsigned int *)t23);
    t29 = (t21 & t20);
    t31 = (t29 != 0);
    if (t31 > 0)
        goto LAB17;

LAB18:
LAB19:    xsi_set_current_line(41, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 4);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 4);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = ((char*)((ng3)));
    memset(t23, 0, 8);
    t12 = (t13 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB23;

LAB22:    t14 = (t11 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB23;

LAB26:    if (*((unsigned int *)t13) > *((unsigned int *)t11))
        goto LAB24;

LAB25:    t22 = (t23 + 4);
    t19 = *((unsigned int *)t22);
    t20 = (~(t19));
    t21 = *((unsigned int *)t23);
    t29 = (t21 & t20);
    t31 = (t29 != 0);
    if (t31 > 0)
        goto LAB27;

LAB28:
LAB29:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 8);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 8);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = ((char*)((ng3)));
    memset(t23, 0, 8);
    t12 = (t13 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB33;

LAB32:    t14 = (t11 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB33;

LAB36:    if (*((unsigned int *)t13) > *((unsigned int *)t11))
        goto LAB34;

LAB35:    t22 = (t23 + 4);
    t19 = *((unsigned int *)t22);
    t20 = (~(t19));
    t21 = *((unsigned int *)t23);
    t29 = (t21 & t20);
    t31 = (t29 != 0);
    if (t31 > 0)
        goto LAB37;

LAB38:
LAB39:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t10 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 12);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t10);
    t16 = (t8 >> 12);
    *((unsigned int *)t5) = t16;
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t17 & 15U);
    t18 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t18 & 15U);
    t11 = ((char*)((ng3)));
    memset(t23, 0, 8);
    t12 = (t13 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB43;

LAB42:    t14 = (t11 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB43;

LAB46:    if (*((unsigned int *)t13) > *((unsigned int *)t11))
        goto LAB44;

LAB45:    t22 = (t23 + 4);
    t19 = *((unsigned int *)t22);
    t20 = (~(t19));
    t21 = *((unsigned int *)t23);
    t29 = (t21 & t20);
    t31 = (t29 != 0);
    if (t31 > 0)
        goto LAB47;

LAB48:
LAB49:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng11)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 16, t4, 16, t5, 32);
    t10 = (t0 + 2248);
    xsi_vlogvar_assign_value(t10, t13, 0, 0, 16);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng11)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 16, t4, 16, t5, 32);
    t10 = (t0 + 2088);
    xsi_vlogvar_assign_value(t10, t13, 0, 0, 16);
    t2 = (t0 + 4968);
    t9 = *((int *)t2);
    *((int *)t2) = (t9 - 1);
    goto LAB6;

LAB10:    xsi_vlogvar_assign_value(t22, t13, 0, *((unsigned int *)t23), 1);
    goto LAB11;

LAB13:    t15 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB15;

LAB14:    *((unsigned int *)t23) = 1;
    goto LAB15;

LAB17:    xsi_set_current_line(40, ng0);
    t24 = (t0 + 2248);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t32, 0, 8);
    t27 = (t32 + 4);
    t28 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    t34 = (t33 >> 0);
    *((unsigned int *)t32) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 0);
    *((unsigned int *)t27) = t36;
    t37 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t37 & 15U);
    t38 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t38 & 15U);
    t39 = ((char*)((ng4)));
    memset(t40, 0, 8);
    xsi_vlog_unsigned_add(t40, 4, t32, 4, t39, 4);
    t41 = (t0 + 2248);
    t45 = (t0 + 2248);
    t46 = (t45 + 72U);
    t47 = *((char **)t46);
    t48 = ((char*)((ng5)));
    t49 = ((char*)((ng1)));
    xsi_vlog_convert_partindices(t42, t43, t44, ((int*)(t47)), 2, t48, 32, 1, t49, 32, 1);
    t50 = (t42 + 4);
    t51 = *((unsigned int *)t50);
    t9 = (!(t51));
    t52 = (t43 + 4);
    t53 = *((unsigned int *)t52);
    t30 = (!(t53));
    t54 = (t9 && t30);
    t55 = (t44 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (!(t56));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB20;

LAB21:    goto LAB19;

LAB20:    t59 = *((unsigned int *)t44);
    t60 = (t59 + 0);
    t61 = *((unsigned int *)t42);
    t62 = *((unsigned int *)t43);
    t63 = (t61 - t62);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t41, t40, t60, *((unsigned int *)t43), t64);
    goto LAB21;

LAB23:    t15 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB25;

LAB24:    *((unsigned int *)t23) = 1;
    goto LAB25;

LAB27:    xsi_set_current_line(41, ng0);
    t24 = (t0 + 2248);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t32, 0, 8);
    t27 = (t32 + 4);
    t28 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    t34 = (t33 >> 4);
    *((unsigned int *)t32) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 4);
    *((unsigned int *)t27) = t36;
    t37 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t37 & 15U);
    t38 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t38 & 15U);
    t39 = ((char*)((ng4)));
    memset(t40, 0, 8);
    xsi_vlog_unsigned_add(t40, 4, t32, 4, t39, 4);
    t41 = (t0 + 2248);
    t45 = (t0 + 2248);
    t46 = (t45 + 72U);
    t47 = *((char **)t46);
    t48 = ((char*)((ng6)));
    t49 = ((char*)((ng7)));
    xsi_vlog_convert_partindices(t42, t43, t44, ((int*)(t47)), 2, t48, 32, 1, t49, 32, 1);
    t50 = (t42 + 4);
    t51 = *((unsigned int *)t50);
    t9 = (!(t51));
    t52 = (t43 + 4);
    t53 = *((unsigned int *)t52);
    t30 = (!(t53));
    t54 = (t9 && t30);
    t55 = (t44 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (!(t56));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB30;

LAB31:    goto LAB29;

LAB30:    t59 = *((unsigned int *)t44);
    t60 = (t59 + 0);
    t61 = *((unsigned int *)t42);
    t62 = *((unsigned int *)t43);
    t63 = (t61 - t62);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t41, t40, t60, *((unsigned int *)t43), t64);
    goto LAB31;

LAB33:    t15 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB35;

LAB34:    *((unsigned int *)t23) = 1;
    goto LAB35;

LAB37:    xsi_set_current_line(42, ng0);
    t24 = (t0 + 2248);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t32, 0, 8);
    t27 = (t32 + 4);
    t28 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    t34 = (t33 >> 8);
    *((unsigned int *)t32) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 8);
    *((unsigned int *)t27) = t36;
    t37 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t37 & 15U);
    t38 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t38 & 15U);
    t39 = ((char*)((ng4)));
    memset(t40, 0, 8);
    xsi_vlog_unsigned_add(t40, 4, t32, 4, t39, 4);
    t41 = (t0 + 2248);
    t45 = (t0 + 2248);
    t46 = (t45 + 72U);
    t47 = *((char **)t46);
    t48 = ((char*)((ng8)));
    t49 = ((char*)((ng9)));
    xsi_vlog_convert_partindices(t42, t43, t44, ((int*)(t47)), 2, t48, 32, 1, t49, 32, 1);
    t50 = (t42 + 4);
    t51 = *((unsigned int *)t50);
    t9 = (!(t51));
    t52 = (t43 + 4);
    t53 = *((unsigned int *)t52);
    t30 = (!(t53));
    t54 = (t9 && t30);
    t55 = (t44 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (!(t56));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB40;

LAB41:    goto LAB39;

LAB40:    t59 = *((unsigned int *)t44);
    t60 = (t59 + 0);
    t61 = *((unsigned int *)t42);
    t62 = *((unsigned int *)t43);
    t63 = (t61 - t62);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t41, t40, t60, *((unsigned int *)t43), t64);
    goto LAB41;

LAB43:    t15 = (t23 + 4);
    *((unsigned int *)t23) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB45;

LAB44:    *((unsigned int *)t23) = 1;
    goto LAB45;

LAB47:    xsi_set_current_line(43, ng0);
    t24 = (t0 + 2248);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t32, 0, 8);
    t27 = (t32 + 4);
    t28 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    t34 = (t33 >> 12);
    *((unsigned int *)t32) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 12);
    *((unsigned int *)t27) = t36;
    t37 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t37 & 15U);
    t38 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t38 & 15U);
    t39 = ((char*)((ng4)));
    memset(t40, 0, 8);
    xsi_vlog_unsigned_add(t40, 4, t32, 4, t39, 4);
    t41 = (t0 + 2248);
    t45 = (t0 + 2248);
    t46 = (t45 + 72U);
    t47 = *((char **)t46);
    t48 = ((char*)((ng2)));
    t49 = ((char*)((ng10)));
    xsi_vlog_convert_partindices(t42, t43, t44, ((int*)(t47)), 2, t48, 32, 1, t49, 32, 1);
    t50 = (t42 + 4);
    t51 = *((unsigned int *)t50);
    t9 = (!(t51));
    t52 = (t43 + 4);
    t53 = *((unsigned int *)t52);
    t30 = (!(t53));
    t54 = (t9 && t30);
    t55 = (t44 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (!(t56));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB50;

LAB51:    goto LAB49;

LAB50:    t59 = *((unsigned int *)t44);
    t60 = (t59 + 0);
    t61 = *((unsigned int *)t42);
    t62 = *((unsigned int *)t43);
    t63 = (t61 - t62);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t41, t40, t60, *((unsigned int *)t43), t64);
    goto LAB51;

LAB52:    xsi_vlogvar_assign_value(t11, t13, 0, *((unsigned int *)t23), 1);
    goto LAB53;

}


extern void work_m_00000000001867732463_0205875555_init()
{
	static char *pe[] = {(void *)Always_30_0};
	xsi_register_didat("work_m_00000000001867732463_0205875555", "isim/controller_controller_sch_tb_isim_beh.exe.sim/work/m_00000000001867732463_0205875555.didat");
	xsi_register_executes(pe);
}
